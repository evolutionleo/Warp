global.clients = [];
global.maps = [];    // loaded in 01_maps.js
global.lobbies = {}; // loaded in 02_lobbies.js