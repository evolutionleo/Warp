// const { hash_password, verify_password } = require('./internal/password_encryption.js');
// const password1 = '123456';
// const password2 = '123456';

// (async () => {
//     const hashed1 = await hash_password(password1);
//     const hashed2 = await hash_password(password2);
//     console.log(hashed1);
//     console.log(hashed2);
//     console.log(await verify_password(password1, hashed1));
//     console.log(await verify_password(password2, hashed2));
//     console.log(await verify_password('12345', hashed2));
//     console.log(await verify_password(password1, hashed2));
// })()
