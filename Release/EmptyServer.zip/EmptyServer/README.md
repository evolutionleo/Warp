# What is this?

- This is a feature-rich server written in NodeJS
- The code is pretty documented, so feel free to look into the sources, tweak stuff, etc. to understand it better

# Where do I start?

- If you feel a bit overwhelmed with all the different files and folder - that's alright,
*you probably don't need to touch most of this stuff* to make a basic online game!
- Take a look in the **custom/** folder, the two files called `handlePacket.js` and `sendStuff.js`
are what you're looking for!
- 