# What is this?
This is a feature-rich JavaScript server, compiled from TypeScript with a couple things improved by hand

# How do I run this?
- Run `npm i` to install all the dependencies
- Run the server via `node .` (or `node server.js`)
- PROFIT!