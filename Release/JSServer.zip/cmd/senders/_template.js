export {};

/**
 * @param {}
 */
// SendStuff.prototype.sendSomething = function() {
//     this.send({ cmd: '',  })
// }
