export {};

// for some reason this dumb file breaks for gulp-typescript when I make it a .d.ts file
// also this file is for linting only, so it should be empty in JS output lol
