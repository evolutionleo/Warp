import { createLobby } from '#util/lobby_functions';
for (var i = 0; i < 3; i++) {
    createLobby();
}
