/** @global */
global.clients = [];
/** @global */
global.maps = [];    // loaded in 01_maps.js
/** @global */
global.lobbies = {}; // loaded in 02_lobbies.js