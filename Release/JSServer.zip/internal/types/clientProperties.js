export default class ClientProperties {
}
