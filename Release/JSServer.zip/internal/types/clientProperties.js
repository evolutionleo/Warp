
export default class ClientProperties {
    socket;
    
    lobby;
    room;
    
    account;
    profile;
    
    halfpack; // used internally in packet.ts
    
    entity;
}
