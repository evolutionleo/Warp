export interface BBox {
    left: number,
    right: number,
    top: number,
    bottom: number
}
export default BBox;