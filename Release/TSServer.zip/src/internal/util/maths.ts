export function clamp(val:number, min:number, max:number) {
    let _val = val;
    if (_val < min) {
        _val = min;
    }
    else if (_val > max) {
        _val = max;
    }

    return _val;
}

export function lerp(start:number, target:number, amount:number) {
    return start + (target - start) * amount;
}

export function approach(start:number, target:number, amount:number) {
    if (start < target) {
        return Math.min(start + amount, target);
    }
    else if (start > target) {
        return Math.max(start - amount, target);
    }
    return start;
}

export function degtorad(deg:number) {
    return deg * Math.PI / 180;
}

export function radtodeg(rad:number) {
    return rad * 180 / Math.PI;
}

export function lengthdir_x(len:number, dir:number) {
    return Math.cos(degtorad(dir)) * len;
}

export function lengthdir_y(len:number, dir:number) {
    return Math.sin(degtorad(dir)) * len;
}

export function lengthdir(len:number, dir:number) {
    return { x: lengthdir_x(len, dir), y: lengthdir_y(len, dir) };
}


// purely for people who don't know that you can just use Math.your_function_here()
// if you are one of them and are reading this right now - please don't import the functions below, use Math.min(), etc. instead

export const sign = Math.sign;
export const abs = Math.abs;
export const random = Math.random;
export const min = Math.min;
export const max = Math.max;
export const ceil = Math.ceil;
export const floor = Math.floor;
export const round = Math.round;
export const sin = Math.sin;
export const cos = Math.cos;
export const tan = Math.tan;