declare global {
    namespace NodeJS {
        interface Global {
            // starting room moved to config
        }
    }
}

export {}