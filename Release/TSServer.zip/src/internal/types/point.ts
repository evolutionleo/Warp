// literally only for the typing
export type Point = {
    x: number,
    y: number
}

export default Point;