import GameMode from "#concepts/game_mode"

export default new GameMode({
    name: '1v1',
    teams: 2,
    team_size: 1,
    ranked: false
});