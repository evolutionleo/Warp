import GameMode from "#concepts/game_mode";

export default new GameMode({
    name: 'FFA',
    teams_enabled: false,
    max_players: 4
});