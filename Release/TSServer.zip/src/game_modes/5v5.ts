import GameMode from "#concepts/game_mode";

export default new GameMode({
    name: '5v5',
    teams_enabled: true,
    team_size: 5,
    teams: 2
});