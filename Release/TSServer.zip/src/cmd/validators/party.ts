import { addValidator } from "#concepts/validator";

addValidator(['party join'], {
    partyid: 'string'
});
