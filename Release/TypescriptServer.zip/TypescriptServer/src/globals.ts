// here you can put any global variables to later import
// (for access across files)
import { Client } from './custom_stuff'

export var clients:Client[] = [];