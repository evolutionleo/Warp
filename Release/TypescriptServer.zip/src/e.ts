import { Schema, model, connect } from 'mongoose';

export default {
    a: "string"
}