export class Entity {
    constructor(x, y) {
        
    }

    tick() {

    }
}