client.on('login', (data) => {

});

client.on('hello', () => {
    console.log('HELLO RECEIVED!!');
});